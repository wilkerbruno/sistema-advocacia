from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db


class Usuario(db.Model, UserMixin):
    """
    Usuário do sistema.

    Papéis (campo `papel`):
      - admin       -> acesso total, todas as unidades, gestão de usuários/unidades
      - gestor      -> gerencia sua própria unidade (equipe, financeiro da unidade)
      - advogado    -> cria/edita processos e demais dados da sua unidade
      - funcionario -> uso operacional (secretaria/estagiário) restrito à sua unidade

    Acesso a dados financeiros (ver PENDENCIAS.md, seção -45): até esta
    rodada, QUALQUER papel logado enxergava a aba Financeiro (inclusive
    funcionário/estagiário) — falha de compliance apontada no relatório de
    avaliação de 20/08/2026. admin e gestor continuam com acesso
    financeiro garantido pelo próprio papel (faz parte do que já se espera
    desses dois cargos). Para os demais (ex: um sócio que atua como
    advogado, sem ser o gestor da unidade), o campo `acesso_financeiro`
    abaixo é a forma explícita de conceder essa visão — sempre uma
    concessão pontual feita por um admin/gestor, nunca automática. Ver
    `pode_ver_financeiro` logo abaixo, que é a checagem única usada em
    todo o sistema (nunca comparar `papel` diretamente para decidir acesso
    financeiro em uma view nova).
    """
    __tablename__ = "usuarios"

    PAPEIS = ("admin", "gestor", "advogado", "funcionario")

    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    senha_hash = db.Column(db.String(255), nullable=False)
    papel = db.Column(db.String(20), nullable=False, default="funcionario")
    oab = db.Column(db.String(30))  # nº OAB, quando aplicável (advogado)
    telefone = db.Column(db.String(30))
    # Número de WhatsApp do próprio usuário (diferente do WhatsApp do
    # Cliente, em app/models/cliente.py) — usado, por exemplo, se um dia
    # o lembrete de compromisso da Agenda passar a avisar o responsável
    # pelo WhatsApp além do cliente (ver app/utils/whatsapp.py).
    whatsapp = db.Column(db.String(30))
    # Concessão explícita de acesso a dados financeiros para quem não é
    # admin/gestor (ver docstring da classe e `pode_ver_financeiro`
    # abaixo). Nullable de propósito — ver sincronizar_schema.py, que não
    # suporta DEFAULT em ALTER TABLE; None é tratado como False em todo
    # lugar que lê este campo.
    acesso_financeiro = db.Column(db.Boolean, default=False, nullable=True)
    # Grupo do menu lateral que ESTE usuário marcou como "favorito" — pedido
    # explícito ("quero [...] uma opção de favoritos em configurações para o
    # cliente selecionar uma categoria desse menu como favorito e ele já
    # aparecer aberto igual o 'operação'", PENDENCIAS.md). É preferência
    # PESSOAL (cada usuário tem a própria, não é por empresa) — ver
    # app/routes/conta.py. Valores possíveis: um dos data-grupo de
    # app/templates/base.html ("operacao", "governanca" ou "config") ou None
    # (nenhum favorito escolhido — cada grupo só abre sozinho quando a
    # página atual está dentro dele, comportamento padrão). Nullable pelo
    # mesmo motivo de `acesso_financeiro`: sincronizar_schema.py não aplica
    # DEFAULT em ALTER TABLE.
    menu_grupo_favorito = db.Column(db.String(20), nullable=True)
    ativo = db.Column(db.Boolean, default=True, nullable=False)
    criado_em = db.Column(db.DateTime, default=datetime.utcnow)
    ultimo_login = db.Column(db.DateTime)

    # Autenticação em duas etapas obrigatória (ver app/utils/totp.py e
    # app/routes/auth.py/conta.py) — TOTP (Google Authenticator/Authy/etc,
    # RFC 6238), o mesmo padrão de app usado por praticamente todo serviço
    # que oferece "app autenticador". O segredo nunca fica em texto puro no
    # banco — cifrado com o MESMO cofre (Fernet) já usado para as chaves de
    # API BYOK (ver app/utils/cofre.py). `totp_confirmado_em` só é
    # preenchido depois que o usuário PROVA que configurou certo (digitou
    # um código válido gerado pelo próprio app dele) — nulo significa
    # "ainda não configurou" (conta nova, ou conta antiga de antes desta
    # funcionalidade existir), mesmo que já exista um segredo PENDENTE
    # gerado em `totp_secret_cifrado` (QR code mostrado mas ainda não
    # confirmado). Ver `totp_configurado` abaixo — é essa propriedade, não
    # os campos direto, que decide se o login exige o código.
    totp_secret_cifrado = db.Column(db.LargeBinary, nullable=True)
    totp_confirmado_em = db.Column(db.DateTime, nullable=True)

    # "Esqueci minha senha" (ver app/utils/senha_redefinicao.py e
    # app/routes/auth.py) — código de 6 dígitos enviado por e-mail, nunca
    # guardado em texto puro (mesmo hash de senha do werkzeug), com prazo
    # de validade e limite de tentativas erradas. Todos nullable: sem
    # nenhuma redefinição pendente, os três ficam vazios.
    reset_senha_codigo_hash = db.Column(db.String(255), nullable=True)
    reset_senha_expira_em = db.Column(db.DateTime, nullable=True)
    reset_senha_tentativas = db.Column(db.Integer, nullable=True)

    # Admin não pertence a nenhuma unidade específica (enxerga todas)
    unidade_id = db.Column(db.Integer, db.ForeignKey("unidades.id"), nullable=True)
    unidade = db.relationship("Unidade", back_populates="usuarios")

    def set_senha(self, senha_texto_puro):
        self.senha_hash = generate_password_hash(senha_texto_puro)

    def checar_senha(self, senha_texto_puro):
        return check_password_hash(self.senha_hash, senha_texto_puro)

    @property
    def totp_configurado(self):
        """True só depois que o usuário CONFIRMOU o autenticador (digitou
        um código válido) — ver app/utils/totp.py. Um segredo pendente
        (QR mostrado, ainda não confirmado) não conta como configurado."""
        return self.totp_confirmado_em is not None

    @property
    def is_admin(self):
        return self.papel == "admin"

    @property
    def is_gestor(self):
        return self.papel == "gestor"

    @property
    def pode_ver_financeiro(self):
        """
        Checagem única de acesso a dado financeiro (Lancamento, aba
        Financeiro, agente de IA "Negócios") — ver PENDENCIAS.md, seção
        -45. admin e gestor sempre têm acesso pelo próprio papel; os
        demais só se tiverem `acesso_financeiro=True` explicitamente
        concedido.
        """
        return self.papel in ("admin", "gestor") or self.acesso_financeiro is True

    @property
    def empresa(self):
        """Empresa a que este usuário pertence, derivada da própria unidade."""
        return self.unidade.empresa if self.unidade else None

    @property
    def empresa_id_atual(self):
        return self.unidade.empresa_id if self.unidade else None

    @property
    def is_admin_desenvolvedor(self):
        """
        Admin da empresa DONA da plataforma — enxerga e administra todas
        as empresas clientes. Nunca aparece para nenhuma outra empresa,
        porque simplesmente não pertence à unidade de nenhuma delas.
        """
        empresa = self.empresa
        return self.papel == "admin" and empresa is not None and empresa.dono_da_plataforma

    def pode_ver_todas_unidades(self):
        return self.papel == "admin"

    def pode_gerenciar_usuarios(self):
        return self.papel in ("admin", "gestor")

    def pode_excluir(self):
        return self.papel == "admin"

    def get_id(self):
        # exigido pelo Flask-Login
        return str(self.id)

    def __repr__(self):
        return f"<Usuario {self.email} ({self.papel})>"
